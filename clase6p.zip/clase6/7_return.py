def sumar(a, b):
    mensaje = "Sumando..."
    print(mensaje)
    return a + b  # devuelve el resultado de la suma (***QUITAR COMENTARIO)
    # Todo lo que está debajo de return no se ejecuta: función como el break de los bucles
    # return None
    # return  # es igual a return None


resultado = sumar(100, 2)
print(resultado)
