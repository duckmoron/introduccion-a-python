def saludar(nombre="No me has pasado un nombre"):
    print(nombre)


saludar()
saludar("Juan")
