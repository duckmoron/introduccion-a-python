def sumar(a, b):
    sumar = a + b
    return sumar


print(sumar(5, 6))

resultado = sumar(5, 6)
print(resultado)
